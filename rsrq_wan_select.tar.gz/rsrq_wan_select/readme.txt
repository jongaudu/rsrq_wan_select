Application Name
================
nysp_wan_select


Application Version
===================
1.0

NCOS Devices Supported
======================
ALL


External Requirements
=====================
None


Application Purpose
===================
This application will change the priority of the WAN interfaces based on RSRQ


Expected Output
===============
