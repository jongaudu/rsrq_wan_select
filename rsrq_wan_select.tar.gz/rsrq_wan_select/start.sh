#!/bin/bash
cppython rsrq_wan_select.py